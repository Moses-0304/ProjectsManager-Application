package model.matcher;

import model.Task;

public interface ITaskMatcher {
    boolean match(Task task);
}
